import os

def rename_log_files(old_word, new_word):
    directory = os.getcwd()  # Get the current working directory
    for filename in os.listdir(directory):
        if filename.endswith(".xyz") and old_word in filename:
            new_filename = filename.replace(old_word, new_word)
            os.rename(os.path.join(directory, filename), os.path.join(directory, new_filename))
            print(f'Renamed: {filename} -> {new_filename}')

# Example usage
old_word = 'g4mp2_opt'
new_word = 'g4mp2'

rename_log_files(old_word, new_word)
